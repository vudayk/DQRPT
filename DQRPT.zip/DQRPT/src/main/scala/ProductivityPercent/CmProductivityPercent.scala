package ProductivityPercent
import org.apache.spark.sql.{DataFrame, Encoders, SQLContext}
import org.apache.spark.sql.types._
import org.apache.spark.sql.functions._
import Utilities.Utils
import com.citius.DQObj.spark
import org.apache.spark.sql.catalyst.analysis.TypeCoercion.numericPrecedence.seq

class CmProductivityPercent extends Utils {

  def CmProductivityPercent(): Unit = {

    import spark.implicits._

    val data1=spark.read.format("csv").option("header","true").load("C:\\bigdatasetup\\BCBS\\files\\ErrorMaster.csv")
    //data1.show(false)
    data1.write.format("csv").option("header","true").mode("overwrite").saveAsTable("bcbssc.ErrorMaster")

    val data6=spark.read.format("csv").option("header","true").load("C:\\bigdatasetup\\BCBS\\files\\cm_wkld_fact.csv")
    //data1.show(false)
    data6.write.format("csv").option("header","true").mode("overwrite").saveAsTable("bcbssc.cm_wkld_fact")


    val prdQueryDf=spark.sql("select productivityquery from bcbssc.ErrorMaster")
    prdQueryDf.show(false)
    //prdQueryDf.withColumn("index",monotonically_increasing_id()).write.mode("overwrite").format("csv").saveAsTable("bcbssc.productivity")
    val prdQueryDf2=prdQueryDf.withColumn("index",monotonically_increasing_id())
    prdQueryDf2.createOrReplaceTempView("Productivity")
    println("********Worked Hours ************")
    val qry1 = spark.sql("select productivityquery from Productivity where index=10").as(Encoders.STRING).collect().toSeq
    val str4 = qry1.flatMap(x=>x.split("\n"))
    val str5=str4.mkString
    val totalworkedhrs=spark.sql(str5).head().mkString
    println(totalworkedhrs)
    println("********Active Hours ************")
    val Aqry1 = spark.sql("select productivityquery from Productivity where index=11").as(Encoders.STRING).collect().toSeq
    val Astr4 = Aqry1.flatMap(x=>x.split("\n"))
    val Astr5=Astr4.mkString
    val totalActivehrs=spark.sql(Astr5).head().mkString
    println(totalActivehrs)
    println("********Prev Worked Hours ************")
    val pwqry1 = spark.sql("select productivityquery from Productivity where index=12").as(Encoders.STRING).collect().toSeq
    val pwstr4 = pwqry1.flatMap(x=>x.split("\n"))
    val pwstr5=pwstr4.mkString
    val totalprevworkedhrs=spark.sql(pwstr5).head().mkString
    println(totalprevworkedhrs)
    println("********PrevActive Hours ************")
    val PAqry1 = spark.sql("select productivityquery from Productivity where index=13").as(Encoders.STRING).collect().toSeq
    val PAstr4 = PAqry1.flatMap(x=>x.split("\n"))
    val PAstr5=PAstr4.mkString
    val totalPrevActivehrs= spark.sql(PAstr5).head().mkString
    println(totalPrevActivehrs)

    //val productivity1 = (2.1 * 100)
    //println(productivity1)
    //val productivity2=(totalworkedhrs.toFloat /totalActivehrs.toFloat)
    //println(productivity2)
    //val productivity3 = productivity1/productivity2
    val currentproductivity = ((2.05*100 )/(totalworkedhrs.toFloat /totalActivehrs.toFloat),8)

    //val currentprdtable = Seq(currentproductivity).toDF("currentproductivityvalue","ErrorID")
    val currentprdtable = Seq(currentproductivity).toDF("NULLCOUNT","ErrorID")

    currentprdtable.show(false)

    println("********Current productivity for CM dashboard************")
    println(currentproductivity)
    val previousproductivity = ((2.05*100 )/(totalprevworkedhrs.toFloat /totalPrevActivehrs.toFloat),8)
    println("********Previous productivity for CM dashboard************")
    println(previousproductivity)

    //val previousprdtable = Seq(previousproductivity).toDF("previousproductivityvalue","ErrorID")
    val previousprdtable = Seq(previousproductivity).toDF("previouscount","ErrorID")

    previousprdtable.show(false)

    val Cmprdtable = currentprdtable.join(previousprdtable,Seq("ErrorID"),"inner")
    Cmprdtable.show(false)

    //Cmprdtable.write.format("csv").option("header","true").mode("overwrite").saveAsTable("bcbssc.CmPrdvtytable")
    //Dmprdtable.write.format("csv").option("header","true").mode("overwrite").save("C:\\bigdatasetup\\BCBS\\files\\output\\DmPrdvtytable")
    val dfmaster = spark.sql("select ErrorID,TableName,ErrorNo,ColumnName,Message,SYS_VOID_STS_IND,reportid from bcbssc.ErrorMaster")

    val masterdf1 = dfmaster.withColumn("dateentered", current_timestamp()).withColumn("dateupdated", current_timestamp()).
      withColumn("createdby", lit("Uday"))

    val resulutcm = masterdf1.join(Cmprdtable,Seq("ErrorID"),"inner").coalesce(1).orderBy("ErrorID")
    println("this is before saving to table")

    resulutcm.show(false)

    resulutcm.write.format("csv").option("header","true").mode("append").saveAsTable("bcbssc.ErrorHeader")
    //Dmprdtable.show(false)



    println("Veera Shivania")
    println("Productivity calculation completed")
    //println(res1)



  }


}
