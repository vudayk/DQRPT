package ProductivityPercent

import Citius.mail.EmailPrdvty
import org.apache.spark.sql.{DataFrame, Encoders, Row, SQLContext}
import org.apache.spark.sql.types._
import org.apache.spark.sql.functions._
import Utilities.Utils
import com.citius.DQObj.spark
import org.apache.spark.sql.catalyst.analysis.TypeCoercion.numericPrecedence.seq

class DmProductivityPercent extends Utils {



  def DmProductivityPercent(): Unit = {

    import spark.implicits._

    val data1=spark.read.format("csv").option("header","true").load("C:\\bigdatasetup\\BCBS\\files\\ErrorMaster.csv")
    //data1.show(false)
    data1.write.format("csv").option("header","true").mode("overwrite").saveAsTable("bcbssc.ErrorMaster")

    val data6=spark.read.format("csv").option("header","true").load("C:\\bigdatasetup\\BCBS\\files\\cm_wkld_fact.csv")
    //data1.show(false)
    data6.write.format("csv").option("header","true").mode("overwrite").saveAsTable("bcbssc.cm_wkld_fact")

    val data7=spark.read.format("csv").option("header","true").load("C:\\bigdatasetup\\BCBS\\files\\emailconfig.csv")
    data7.write.format("csv").option("header","true").mode("overwrite").saveAsTable("bcbssc.emailconfig")


    val prdQueryDf=spark.sql("select productivityquery from bcbssc.ErrorMaster ")
    prdQueryDf.show(false)
    //prdQueryDf.withColumn("index",monotonically_increasing_id()).write.mode("overwrite").format("csv").saveAsTable("bcbssc.productivity")
    val prdQueryDf2=prdQueryDf.withColumn("index",monotonically_increasing_id())
    prdQueryDf2.createOrReplaceTempView("Productivity")
    println("********Worked Hours ************")
    val qry1 = spark.sql("select productivityquery from Productivity where index=6 ").as(Encoders.STRING).collect().toSeq
    val str4 = qry1.flatMap(x=>x.split("\n"))
    val str5=str4.mkString
    val totalworkedhrs=spark.sql(str5).head().mkString
    println(totalworkedhrs)
    println("********Active Hours ************")
    val Aqry1 = spark.sql("select productivityquery from Productivity where index=7  ").as(Encoders.STRING).collect().toSeq
    val Astr4 = Aqry1.flatMap(x=>x.split("\n"))
    val Astr5=Astr4.mkString
    val totalActivehrs=spark.sql(Astr5).head().mkString
    println(totalActivehrs)
    println("********Prev Worked Hours ************")
    val pwqry1 = spark.sql("select productivityquery from Productivity where index=8 ").as(Encoders.STRING).collect().toSeq
    //pwqry1.foreach(println)
    val pwstr4 = pwqry1.flatMap(x=>x.split("\n"))
    val pwstr5=pwstr4.mkString
    val totalprevworkedhrs=spark.sql(pwstr5).head().mkString
    println(totalprevworkedhrs)
    println("********PrevActive Hours ************")
    val PAqry1 = spark.sql("select productivityquery from Productivity where index=9 ").as(Encoders.STRING).collect().toSeq
    val PAstr4 = PAqry1.flatMap(x=>x.split("\n"))
    val PAstr5=PAstr4.mkString
    val totalPrevActivehrs= spark.sql(PAstr5).head().mkString
    println(totalPrevActivehrs)

    //val productivity1 = (2.1 * 100)
    //println(productivity1)
    //val productivity2=(totalworkedhrs.toFloat /totalActivehrs.toFloat)
    //println(productivity2)
    //val productivity3 = productivity1/productivity2
   //val currentproductivity = ((2.1*100 )/(totalworkedhrs.toFloat /totalActivehrs.toFloat),1)
    val currentproductivity = ((2.1*100 )/(totalworkedhrs.toFloat /totalActivehrs.toFloat),7)
    //currentproductivity.foreach(println)

    //val currentprdtable = Seq(currentproductivity).toDF("currentproductivityvalue","ErrorID")
    val NULLCOUNTdf = Seq(currentproductivity).toDF("NULLCOUNT","ErrorID")

    NULLCOUNTdf.show(false)

    println("********Current productivity for DM dashboard************")
    println(currentproductivity)
    val previousproductivity = ((2.1*100 )/(totalprevworkedhrs.toFloat /totalPrevActivehrs.toFloat),7)
    println("********Previous productivity for DM dashboard************")
    println(previousproductivity)

    val previouscountdf = Seq(previousproductivity).toDF("previouscount","ErrorID")
    /*val schema = StructType( Array(
      StructField("NULLCOUNT", StringType,true),
      StructField("previouscount", StringType,true),
      StructField("ErrorID", IntegerType,true)
    ))*/

//val rdd1=spark.sparkContext.parallelize("Seq(Row(currentproductivity),Row(previousproductivity),Row(7)")

    //val df1=Seq(List(currentproductivity,previousproductivity,7)).toDF("NULLCOUNT","previouscount","ErrorID")

    //df1.show(false)

    //case class schema(NULLCOUNT:Double,previouscount:Double,ErrorID:Int)

    //val df=rdd1.map(x=>x.split(","))

    //val df1=df.map(x=>schema(x(0),x(1),x(2).toInt)



    //val resultdm:DataFrame = spark.createDataFrame()

//val resultdm = df1.join(data1,Seq("ErrorID"),"inner")



    //resultdm.write.format("csv").option("header","true").mode("append").saveAsTable("bcbssc.ErrorHeader")


    //val Dmprdtable = currentprdtable.join(previousprdtable,Seq("ErrorID"),"inner").withColumn("executeddate", current_timestamp())
    val Dmprdtable = NULLCOUNTdf.join(previouscountdf,Seq("ErrorID"),"inner")
    Dmprdtable.show(false)

    val dfmaster = spark.sql("select ErrorID,TableName,ErrorNo,ColumnName,Message,SYS_VOID_STS_IND,reportid from bcbssc.ErrorMaster")

    val masterdf1 = dfmaster.withColumn("dateentered", current_timestamp()).withColumn("dateupdated", current_timestamp()).
      withColumn("createdby", lit("Uday"))

    val resulutdm = masterdf1.join(Dmprdtable,Seq("ErrorID"),"inner").coalesce(1).orderBy("ErrorID")
    println("this is before saving to table")

    resulutdm.show(false)

    resulutdm.write.format("csv").option("header","true").mode("append").saveAsTable("bcbssc.ErrorHeader")
    //Dmprdtable.show(false)

    //Dmprdtable.write.format("csv").option("header","true").mode("overwrite").saveAsTable("bcbssc.DmPrdvtytable")
    //Dmprdtable.write.format("csv").option("header","true").mode("overwrite").save("C:\\bigdatasetup\\BCBS\\files\\output\\DmPrdvtytable")


    val currentproductivityvalue = ((2.1*100 )/(totalworkedhrs.toFloat /totalActivehrs.toFloat))
    val previousproductivityvalue = ((2.1*100 )/(totalprevworkedhrs.toFloat /totalPrevActivehrs.toFloat))

    var msgprdvty=""
val diffpercentage = (currentproductivityvalue-previousproductivityvalue)
    if (diffpercentage >=10|| diffpercentage<= -10)
    {
      println("Difference is more than 10%")
      msgprdvty="current productivity is more than 10% previous value"

    }

    else
      {
        println("Difference is less than 10%")
        msgprdvty="current productivity is less than 10% previous value"

      }


    val reportidemail = data1.join(data7, Seq("reportid"), "inner")

    //val emaildf = reportidemail.select("recipientemaild").filter(col("reportid")===2).map(x=>x.getString(0)).collect.toList
    val emaildf = reportidemail.filter(col("recipientemaild").isNotNull).select("recipientemaild")

    val obj = new EmailPrdvty("C:\\Users\\udayv\\IdeaProjects\\DQRPT\\src\\main\\Resources\\application.conf")
    //obj.sendMail(msg, spark.sparkContext.applicationId, "", "R", "")
    obj.sendMail(msgprdvty, spark.sparkContext.applicationId, "", "R", "",emaildf,spark)
    //spark.stop()

    println("Veera Shivania")
    println("Productivity calculation completed")
    //println(res1)



  }
}