package Citius.mail
import Utilities.Utils

import javax.activation.{CommandMap, MailcapCommandMap}
import javax.mail.{Message, Session}
import javax.mail.internet.{InternetAddress, MimeBodyPart, MimeMessage, MimeMultipart}
import com.typesafe.config.ConfigFactory
import org.apache.spark.sql.{DataFrame, Encoders}
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.{DataFrame, Encoders, SparkSession}
//import shapeless.syntax.std.tuple.unitTupleOps

import java.io.File
import java.util.{Calendar, Properties}

class EmailPrdvty (Conf:String) extends Utils{

  var Email_host:String = ""
  var Email_port :String= ""
  var Email_username :String= ""
  var Email_password :String= ""
  var Email_recipient:String=""
  var SparkAppName:String=""
  var Email_Auth:String =""
  var email_ssl_enable:String = "false"
  var email_starttls_enable:String = "true"
  var email_smtp_ssl_protocols:String = "TLSv1.2"
  var email_smtp_ssl_trust:String = "citiustech-com.mail.protection.outlook.com"

  def ConfLoader():Unit = {
    try{
      val config = ConfigFactory.parseFile(new File(Conf))
      Email_username = config.getString("email.email_username")
      Email_password = config.getString("email.email_password")
      //Email_recipient=config.getString("email.email_recipient")
      //Email_recipient= emaildf
      Email_host=config.getString("email.email_host")
      Email_port=config.getString("email.email_port")
      Email_Auth = config.getString("email.email_auth").toLowerCase
      SparkAppName = config.getString("spark.appName")
      email_ssl_enable = config.getString("email.email_ssl_enable").toLowerCase
      email_starttls_enable = config.getString("email.email_starttls_enable").toLowerCase
      email_smtp_ssl_protocols = config.getString("email_smtp_ssl_protocols").toLowerCase
      email_smtp_ssl_trust = config.getString("email_smtp_ssl_trust").toLowerCase
    } catch {
      case e:Exception => println("[Email:ConfLoader]........Error Occurred:..." + e)
    }
  }

  //def sendMail(text: String,appId:String = "",Subject:String ="",MailType:String="",defaultMsg:String ="",attachFile:String=""):Unit = {
  def sendMail(text: String, appId:String = "", Subject:String ="", MailType:String="", defaultMsg:String ="", emaildf:DataFrame,spark:SparkSession, attachFile:String=""):Unit = {
    ConfLoader()
    try{

      val mc = CommandMap.getDefaultCommandMap.asInstanceOf[MailcapCommandMap]
      mc.addMailcap("text/html;; x-java-content-handler=com.sun.mail.handlers.text_html")
      mc.addMailcap("text/xml;; x-java-content-handler=com.sun.mail.handlers.text_xml")
      mc.addMailcap("text/plain;; x-java-content-handler=com.sun.mail.handlers.text_plain")
      mc.addMailcap("multipart/*;; x-java-content-handler=com.sun.mail.handlers.multipart_mixed")
      mc.addMailcap("message/rfc822;; x-java-content-handler=com.sun.mail.handlers.message_rfc822")
      CommandMap.setDefaultCommandMap(mc)
      // Thread.currentThread.setContextClassLoader(getClass.getClassLoader)
      val DateTime = Calendar.getInstance().getTime

      val properties = new Properties()
      properties.put("mail.smtp.port", Email_port)
      properties.put("mail.smtp.auth", Email_Auth)
      properties.put("mail.smtp.ssl.enable", email_ssl_enable)
      properties.put("mail.smtp.starttls.enable", email_starttls_enable)
      properties.put("mail.smtp.ssl.protocols", email_smtp_ssl_protocols)
      properties.put("mail.smtp.ssl.trust", email_smtp_ssl_trust)


      val session = Session.getDefaultInstance(properties)
      import spark.implicits._
      val message = new MimeMessage(session)
      emaildf.show(false)
      val emailid1 = emaildf.filter(col("reportid")===3).map(x=>x.getString(0)).collect().toList
      println("test1")
      emailid1.foreach(println)
      println("test2")
      val recipientList= emailid1
      //val recipientList= ""
      //recipientList.foreach(println)
      println("test3")
      //val Email_recipient= emailid1
      //Email_recipient.foreach(println)
      //println("above is output of email_recipient")
      //Email_recipient.foreach(println)
      //val recipientList:List[String] = Email_recipien
      //val recipientList:List[String] = Email_recipient.map(x=>x.split("\t"))

      recipientList.foreach { recipient =>
        message.addRecipient(Message.RecipientType.TO, new InternetAddress(recipient))


      }


      if(Subject.isEmpty) {
        message.setSubject("Alert: Spark " + SparkAppName + " Job.")
      } else {
        message.setSubject(Subject)
      }

      var SparkJobName:String = ""

      if (appId.isEmpty || appId.trim == ""){
        SparkJobName = "'" + SparkAppName + "'"
      } else {
        SparkJobName = "'" + SparkAppName + "( " + appId + " ) '"
      }

      var defMsg:String = ""

      var msg = ""
      if(MailType.toUpperCase() == "F") {
        if (defaultMsg.isEmpty || defaultMsg.trim() == ""){
          defMsg = "<br><h3>Spark Job <b>" + SparkJobName + "</b> has been Failed On Date Time" + DateTime + "</h3>" + "<br><u><b>Failed due to below reason:</b></u>"
        } else {
          defMsg = "<br><h3>" + defaultMsg + "</b></h3>"
        }

        msg = "<br>" +
          defMsg +
          "<br><p><font " + "face=" + "Lucida Console" + ">" + text + "</font></p>"
      } else if (MailType.toUpperCase() == "R") {
        if (defaultMsg.isEmpty || defaultMsg.trim() == ""){
          defMsg = "<br><h3><b>Please find below Productivity Report:</b></h3>"
        } else defMsg = "<br><h3>" + defaultMsg + "</b></h3>"
        msg = defMsg + "<br>" + text
      } else {
        defMsg = "<br><h3>" + defaultMsg + "</b></h3>"

        msg = "<br>" + defMsg +
          "<br><p><font " + "face=" + "Lucida Console" + ">" + text + "</font></p>"
      }

      val fileList:List[String] = attachFile.split(";").toList

      val MessagePart = new MimeMultipart()
      val BodyPartText = new MimeBodyPart()
      BodyPartText.setText(msg,"utf-8","html")
      MessagePart.addBodyPart(BodyPartText)
      if(attachFile != ""){
        fileList.foreach { x =>
          val Attachment = new MimeBodyPart()
          val fileName = x.split(",").head
          val filePath = x.split(",").tail.mkString.trim()

          if(filePath != ""|| !filePath.isEmpty) {
            Attachment.attachFile(filePath)
            Attachment.setFileName(fileName)
            MessagePart.addBodyPart(Attachment)
          } else{
            Attachment.attachFile(fileName)
            MessagePart.addBodyPart(Attachment)
          }
        }
      }
      message.setContent(MessagePart)


      val transport = session.getTransport("smtp")

      // Thread.currentThread.setContextClassLoader(getClass.getClassLoader)
      transport.connect(Email_host, Email_username, Email_password)
      transport.sendMessage(message, message.getAllRecipients)

      transport.close()
      println("[Email:sendMail]........Email Sent Successfully:...")
    } catch {
      case e:Exception => println("[Email:sendMail]........Error Occurred:..." + e)
    }
  }


}
