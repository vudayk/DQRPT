package com.citius
import org.apache.spark.sql.{DataFrame, Encoders, SparkSession}
import NullRecords.NullRecords
import ProductivityPercent.{CmProductivityPercent, DmProductivityPercent}
import Utilities.Utils
import RowCount.RowCount
import org.apache.spark.SparkContext
import org.apache.spark.SparkConf
import org.apache.spark.sql.types._
import org.apache.spark.sql.functions._
/*import org.apache.spark.sql.hive.HiveSessionStateBuilder
import org.apache.hadoop.hive.conf.HiveConf*/

object DQObj extends Utils{

  def main(args: Array[String]): Unit = {


    import spark.implicits._
    /*******************************
     * this is for NullRecord program
     *******************************/

    val data1=spark.read.format("csv").option("header","true").load("C:\\bigdatasetup\\BCBS\\files\\ErrorMaster.csv")
    //data1.show(false)
    data1.write.format("csv").option("header","true").mode("overwrite").saveAsTable("bcbssc.ErrorMaster")

    val data6=spark.read.format("csv").option("header","true").load("C:\\bigdatasetup\\BCBS\\files\\cm_wkld_fact.csv")
    //data1.show(false)
    data6.write.format("csv").option("header","true").mode("overwrite").saveAsTable("bcbssc.cm_wkld_fact")

    val data11=spark.read.format("csv").option("header","true").load("C:\\bigdatasetup\\BCBS\\files\\MA_MEMB_CVG_CMP.csv")
    //data1.show(false)
    data11.write.format("csv").option("header","true").mode("overwrite").saveAsTable("bcbssc.MA_MEMB_CVG_CMP")

    val data12=spark.read.format("csv").option("header","true").load("C:\\bigdatasetup\\BCBS\\files\\MA_MEMB_DIM.csv")
    //data1.show(false)
    data12.write.format("csv").option("header","true").mode("overwrite").saveAsTable("bcbssc.MA_MEMB_DIM")


    val nullR=new NullRecords
    nullR.getNullRecords()

    /*******************************
     * this is for DM Productivity program
     *******************************/
    //val ProductivityP=new DmProductivityPercent
    //ProductivityP.DmProductivityPercent()

    /*******************************
     * this is for CM Productivity program
     *******************************/
    //val ProductivityCM=new CmProductivityPercent
    //ProductivityCM.CmProductivityPercent()



    println("   ")
    //println("Jai Bhavani")
    println("Program executed successfully")

  }

}
