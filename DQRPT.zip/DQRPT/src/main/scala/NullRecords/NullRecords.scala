package NullRecords
import org.apache.spark.sql.{DataFrame, Encoders, SQLContext}
import org.apache.spark.sql.types._
import org.apache.spark.sql.functions._
import Utilities.Utils
import com.citius.DQObj.spark
import Citius.mail.EmailRcp
import Citius.mail.Email



class NullRecords extends Utils{
  def getNullRecords():Unit = {


    import spark.implicits._
    //implicit val myObjEncoder = org.apache.spark.sql.Encoders.kryo[NullRecords]

    val data1 = spark.read.format("csv").option("header", "true").load("C:\\bigdatasetup\\BCBS\\files\\ErrorMaster.csv")
    //data1.show(false)
    data1.write.format("csv").option("header", "true").mode("overwrite").saveAsTable("bcbssc.ErrorMaster")

    //val data10=spark.read.format("csv").option("header","true").load("C:\\bigdatasetup\\BCBS\\files\\ErrorHeader.csv")
    //data1.show(false)
    //data10.write.format("csv").option("header","true").mode("overwrite").saveAsTable("bcbssc.ErrorHeader")

    val data7 = spark.read.format("csv").option("header", "true").load("C:\\bigdatasetup\\BCBS\\files\\emailconfig.csv")
    data7.write.format("csv").option("header", "true").mode("overwrite").saveAsTable("bcbssc.emailconfig")
    //data4.show(false)


    val dfmaster = spark.sql("select ErrorID,TableName,ErrorNo,ColumnName,Message,SYS_VOID_STS_IND,reportid from bcbssc.ErrorMaster")

    val masterdf1 = dfmaster.withColumn("dateentered", current_timestamp()).withColumn("dateupdated", current_timestamp()).
      withColumn("createdby", lit("Uday")).withColumn("previouscount", lit(0))

    val queriesDF = spark.read.table("bcbssc.ErrorMaster")

    val queries1 = queriesDF.select("NcountQuery").where(col("NcountQuery").isNotNull).distinct().as(Encoders.STRING).collect().toSeq

    queries1.foreach(println)
    val queryResults1 = queries1.map(q => (q, spark.sql(q).as(Encoders.STRING).first()))


    val queryResultsDF1 = queryResults1.toDF("NcountQuery", "NULLCOUNT")


    // queryResultsDF1.show(false)
    /** ******************************************************* */
    val dfnullcount = queriesDF.alias("queriesDF")
      .join(queryResultsDF1, Seq("NcountQuery"))
      .select("queriesDF.ErrorID", "NULLCOUNT")
    println("this is value of dfnullcount")
    dfnullcount.show(false)

    val dfnullfinal = dfnullcount.join(masterdf1, Seq("ErrorID"), "inner").coalesce(1).orderBy("ErrorID")


    dfnullfinal.write.format("csv").option("header", "true").mode("append").saveAsTable(s"bcbssc.ErrorHeader")
    dfnullfinal.show(false)
    println("Errorheader table created successfully")

    val reportidemail = data1.join(data7, Seq("reportid"), "inner")

    //val emaildf = reportidemail.select("recipientemaild").filter(col("reportid")===2).map(x=>x.getString(0)).collect.toList
    val emaildf = reportidemail.filter(col("recipientemaild").isNotNull).select("recipientemaild")

    //val emailids = emaildf.mkString(",")

    //emaildf.foreach(println)
    //emaildf.show(false)
    //--------------------------------------------------------------------------------------------------
    /** *****************************
     * this is for Error details
     * ***************************** */
    //spark.sql("truncate table bcbssc.errordetail")
    spark.sql("truncate table bcbssc.PreErrorDetail")
    val queries2 = queriesDF.select("DetailQuery").where(col("DetailQuery").isNotNull).distinct().as(Encoders.STRING).collect().toSeq
    queries2.foreach(println)
    println("Executed this")
    val queries3 = queries2.flatMap(x => x.split("\n"))
    val queryResults2 = queries3.map(x => spark.sql(x))
    queryResults2.foreach(println)

    //spark.sql("truncate table bcbssc.PreErrorDetail")
    val errorDF = spark.sql("select * from bcbssc.PreErrorDetail")
    errorDF.show()

    //val ErrorDetailDF = errorDF.join(queriesDF,Seq("ErrorID"),"inner").drop("Countquery","NcountQuery","DetailQuery")
    //ErrorDetailDF.show()
    val ErrorDetailDF = errorDF.join(dfnullfinal, Seq("ErrorID"), "inner").drop("NULLCOUNT").drop("previouscount")

    ErrorDetailDF.write.format("csv").option("header", "true").mode("overwrite").saveAsTable("bcbssc.ErrorDetail")

    val maildfnull = dfnullfinal.drop("TableName", "ErrorNo", "ColumnName", "SYS_VOID_STS_IND", "reportid", "dateupdated", "createdby", "previouscount")

    val maxval = queriesDF.where(col("reportid").isNotNull).selectExpr("reportid").dropDuplicates().collect().toList
    maxval.foreach(println)


      for( i <- 1 to 2   ){


      val mailidfinaloutput = maildfnull.where(col("reportid")===i).selectExpr(
        "ErrorID as ErrorID",
        "Message as Message",
        "NULLCOUNT as Count",
        "dateentered as executiondate"
      )


    val msg = createHtmlEmailBody(mailidfinaloutput)

    val obj = new EmailRcp("C:\\Users\\udayv\\IdeaProjects\\DQRPT\\src\\main\\Resources\\application.conf")
    //obj.sendMail(msg, spark.sparkContext.applicationId, "", "R", "")
    obj.sendMail(msg, spark.sparkContext.applicationId, "", "R", "",emaildf,spark,"",i)
    //spark.stop()

  }

  def createHtmlEmailBody(df: DataFrame): String = {
    val columnNames = df.columns.map(x => "<th>" + x.trim + "</th>").mkString
    //println("this is columnnames result")
    //columnNames.foreach(println)
    val data = df.collect.mkString
    //println("this is data result")
    //data.foreach(println)
    val data1 = data.split(",").map(x => "<td>".concat(x).concat("</td>"))
    //println("this is data1 result")
    //data1.foreach(println)
    val data2 = data1.mkString.replaceAll("<td>\\[", "<tr><td>")
    //println("this is data2 result")
    //data2.foreach(println)
    val data3 = data2.mkString.replaceAll("]\\[", "</td></tr><td>").replaceAll("]", "")
    //println("this is data3 result")
    //data3.foreach(println)

    val msg =
      s"""<!DOCTYPE html>
         |<html>
         |   <head>
         |      <style>
         |         table {
         |            border: 1px solid black;
         |         }
         |         th {
         |          border: 1px solid black;
         |          background-color: #FFA;
         |          }
         |         td {
         |          border: 1px solid black;
         |          background-color: #FFF;
         |          }
         |      </style>
         |   </head>
         |
         |   <body>
         |      <h1>Report</h1>
         |      <table>
         |         <tr> $columnNames </tr>$data3
         |      </table>
         |   </body>
         |</html>""".stripMargin
    //println("this is msg result")
    //msg.foreach(println)
    msg
  }

    }

}



